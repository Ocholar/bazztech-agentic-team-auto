# BazzAI Website Implementation — AGENT EXECUTION GUIDE
## How to Use the Prompt Architecture to Manage End-to-End Implementation

---

## OVERVIEW

You now have a **complete prompt architecture** for orchestrating the BazzAI website implementation:

1. **Master Prompt** (`bazzai_implementation_agent_prompt.md`) — Overarching directives, success metrics, escalation paths
2. **Phase 1 Sub-Prompt** (`bazzai_phase1_subprompt.md`) — Detailed execution for Weeks 1–3
3. **Phase 2–4 Sub-Prompts** (to be created as you progress)

These prompts are designed to:
- **Guide an agent** (human project manager, AI orchestrator, or combination) through a 10-week execution
- **Eliminate ambiguity** around what needs to be done and by when
- **Define success clearly** (metrics, deliverables, quality standards)
- **Provide escalation paths** when blockers arise
- **Enable accountability** (weekly reports, phase-completion audits)

---

## HOW TO USE THIS PROMPT ARCHITECTURE

### Option 1: Hire a Human Project Manager
Print all prompts and give them to a PM. They will:
- Use the Master Prompt as their "project charter"
- Reference Phase 1 Sub-Prompt for detailed execution guidance
- Track weekly progress against success criteria
- Escalate blockers using the Escalation Matrix
- Report every Friday using the Weekly Status Report template

**Ideal PM Profile:** Someone with marketing/product experience, SaaS knowledge, and ability to corral designers/writers.

**Estimated Cost:** $5k–8k/month for 10 weeks (freelance PM rates)

---

### Option 2: Assign an Internal Project Lead
If you have an existing PM or product manager on your team:
- Share the Master Prompt as the "10-week roadmap"
- Give them authority to coordinate Dev, Design, Content Writer
- Weekly check-ins to review progress against the prompts
- Escalation to Reagan (you) when decisions are needed

**Estimated Effort:** 40% of one PM's time for 10 weeks

---

### Option 3: Use an AI Agent
Feed the entire prompt architecture to Claude (or another LLM agent framework like CrewAI, Anthropic Workbench, etc.):

```
I'm providing you with a comprehensive implementation roadmap for a website overhaul. 
Your job is to orchestrate the execution of all 17 initiatives across 10 weeks.

Here's the Master Prompt [copy full text]:
[Entire bazzai_implementation_agent_prompt.md]

Here's the Phase 1 Sub-Prompt [copy full text]:
[Entire bazzai_phase1_subprompt.md]

Your responsibilities:
1. Follow the execution timeline exactly
2. Generate weekly status reports every Friday (use the template provided)
3. Identify blockers and escalate immediately (don't wait until Friday)
4. Coordinate deliverables between Content, Design, Dev, and Product
5. Track analytics metrics weekly
6. Maintain a shared dashboard (Notion/Asana) with all initiative status

Start immediately. First action: Schedule Week 1 kickoff meeting with [names].
```

The agent will:
- Break down each initiative into weekly tasks
- Identify dependencies and blockers
- Generate weekly reports
- Recommend escalations when needed
- Suggest optimizations as it learns your team's capacity

**Note:** An AI agent cannot execute creative work (write copy, design pages), but can orchestrate, coordinate, and track progress of humans doing that work.

---

### Option 4: Hybrid Approach (Recommended)
- **Human PM** owns execution + team coordination + creative oversight
- **AI Agent** owns orchestration + metrics tracking + weekly reporting + escalation monitoring
- **You (Reagan)** make final decisions + unblock when needed + celebrate wins

This combines the strengths of both:
- Human judgment on creative direction
- AI efficiency on tracking, reporting, escalation
- You stay informed without micromanaging

**Setup:**
1. Hire freelance PM for Phases 1–2 (most critical)
2. Have AI agent shadow the PM, generating automated weekly reports
3. By Phase 3, transition to mostly AI orchestration (PM steps back)

---

## GETTING STARTED: WEEK 1 KICKOFF

### Pre-Meeting Prep (You, 30 min)
1. Read the Master Prompt (entire document)
2. Read the Phase 1 Sub-Prompt (sections 1–5)
3. Prepare a team roster (who owns what?)
4. Reserve a shared workspace (Notion, Asana, or GitHub Projects)

### Week 1 Kickoff Meeting (1 hour)

**Attendees:** You (Reagan), Project Lead (PM or AI agent), Product/Marketing Lead, Dev Lead, Content Lead, Designer (optional)

**Agenda:**

1. **Welcome & Context (5 min)**
   - "We're executing a 10-week website overhaul to go from 6.5/10 to 9/10 conversion ready."
   - "Three blind spots we're fixing: competitive moat, enterprise credibility, implementation transparency."
   - "17 initiatives across 4 phases. Hard deadlines for Phases 1–3."

2. **Master Roadmap Overview (10 min)**
   - Walk through 4 phases + 17 initiatives
   - Emphasize: Phase 1 is critical path. Zero slippage.
   - "By Week 3, we'll have 5 initiatives live. By Week 6, 9. By Week 10, 13."

3. **Team Assignments (10 min)**
   - "PM: You own overall orchestration. Use the Master Prompt as your bible."
   - "Content: You own 1.1 (Why BazzAI), 1.4 (Case Study), 2.2 (Verticals), 3.1 (Thought Leadership)"
   - "Design: You own layouts for all new pages. Timeline: [dates]"
   - "Dev: You own builds + analytics + performance. Timeline: [dates]"
   - Each person should have the relevant sub-prompt (Phase 1, Phase 2, etc.)

4. **Phase 1 Critical Path (15 min)**
   - "Pricing strategy must be locked by Monday EOD. Reagan, when can you finalize this?"
   - "Customer outreach for case studies starts today. Sales Lead, can you identify 10 customers by EOD today?"
   - "Reagan's founder bio + team photos needed by Wednesday."
   - "No floating assumptions. If you're blocked, escalate immediately."

5. **Success Metrics & Reporting (10 min)**
   - "We measure success with: conversion rate, traffic, downloads, bounce rate."
   - "Every Friday 5pm, PM sends status report (template in Master Prompt)."
   - "If anything is at risk, PM escalates immediately (don't wait for Friday)."
   - Review Weekly Status Report template together.

6. **Questions & Closeout (10 min)**
   - "Any blockers before we start?"
   - "Everyone confident in their piece?"
   - "Let's ship this."

### Immediate Post-Meeting Actions (PM, 1 hour)

1. **Create shared dashboard** (Notion or Asana):
   - 17 initiatives as cards/rows
   - Status column (Not Started, In Progress, Complete)
   - Responsible person
   - Deadline
   - Blockers/notes

2. **Schedule recurring meetings:**
   - Weekly PM + You (Reagan): Wednesdays 3pm (15 min sync on blockers)
   - Weekly full team: Friday 4pm (15 min recaps, next week prep)

3. **Send team calendar invites + access to all prompts**

4. **Begin Week 1 tasks** (per Phase 1 Sub-Prompt):
   - Content: Start researching competitors for Initiative 1.1
   - PM: Lock pricing strategy (meeting with Reagan + Finance)
   - Sales: Begin customer outreach
   - You (Reagan): Provide founder bio + team photos + any strategic input

---

## WEEKLY RHYTHM

Every week follows a predictable pattern:

### Monday (Team)
- PM reviews the week's initiatives
- Identify any blockers from last week that are still pending
- Confirm external dependencies are scheduled (customer interviews, feedback cycles, etc.)
- Team Slack message: "Week [X] priorities: [1], [2], [3]. No blockers yet. LMK if anything comes up."

### Tuesday–Thursday (Execution)
- Content writes
- Design designs
- Dev develops
- PM coordinates + removes blockers
- Daily async updates (no meetings unless blocked)

### Friday (Reporting)
- PM compiles Weekly Status Report (using template from Master Prompt)
- Updates shared dashboard
- Reports metrics: traffic, CTAs, conversions
- Flags any at-risk initiatives for Phase 2
- Sends report to team + You by 5pm
- Optional Friday 4pm sync: 15-min team debrief on wins + next week's focus

---

## MANAGING BLOCKERS

Use the Escalation Matrix from the Master Prompt:

| Blocker | Escalate To | By When | Action |
|---------|------------|--------|--------|
| Pricing delay | You + PM | Same day | "Recommend publish custom pricing while finalizing." |
| No customer interviews | Sales Lead | Next day | "Try 5 other customers. If all decline, pivot to [vertical]." |
| Designer over-capacity | PM | Same week | "Need $1k freelance support. Approve?" |
| Page underperforms | Dev | 2 days | "Optimize images + scripts. Retest by [date]." |
| Scope creep | You | Same day | "Out of scope. Add to Phase 4 instead." |
| Timeline slip | You + PM | 5 days before | "Initiative [X] will slip 1 week. Root cause: []. Options: [A] or [B]." |

**Key principle:** Flag early, escalate quickly. A blocker on Wednesday is solvable. A blocker on Friday threatens the deadline.

---

## MEASURING SUCCESS

### Weekly Metrics (Tracked Every Friday)

Create a simple Google Sheet or Notion dashboard:

```
Week | Traffic | Pricing % | Case Study DL | Assessment Books | Bounce Rate | Status
-----|---------|-----------|----------------|------------------|-------------|--------
  1  |    N/A  |    N/A    |      N/A       |       N/A        |     N/A     | Prepping
  2  |   1.2k  |    3%     |       8        |        2         |     42%     | 3/5 live
  3  |   1.8k  |    8%     |      15        |        5         |     38%     | 5/5 live ✅
  4  |   2.1k  |   10%     |      18        |        7         |     36%     | 4/4 live ✅
  ...
 10  |   4.2k  |   12%     |      28        |       18         |     30%     | 13/17 live ✅
```

### Phase Completion Audit (End of Each Phase)

Use the Phase Completion Report template from Master Prompt:
- List all deliverables + status
- Capture metrics improvement
- Document learnings
- Identify optimizations for next phase

### 10-Week Final Report (Week 10 EOD)

Compile:
- All 17 initiatives delivered (with links/evidence)
- Metrics impact (conversion score 6.5 → 9/10)
- Cost summary (hours spent vs. estimate)
- Learnings & playbook for ongoing optimization
- Celebrate the team

---

## COMMON PITFALLS & HOW TO AVOID THEM

### Pitfall 1: "I Don't Have Time to Do This"
**Reality:** You're the bottleneck. Founder input is critical (bios, decisions, final reviews).
**Solution:** Block 2 hours/week on your calendar. Respond to PM requests within 24 hours. Don't postpone decisions.

### Pitfall 2: "Pricing Is Too Complex"
**Reality:** Perfect pricing is the enemy of done. You can refine after launch.
**Solution:** Lock a "good enough" pricing by Monday Week 1. Publish. Iterate in Phase 4.

### Pitfall 3: "Customers Won't Respond to Case Study Requests"
**Reality:** Many will if you offer an incentive (1 free month, featured testimonial, exec summary).
**Solution:** PM should reach out to 10 customers with incentive. Expect 50% yes rate. Aim for 5–8 confirmations.

### Pitfall 4: "Designer Is Too Busy"
**Reality:** You might need freelance support. Budget $1k–2k for this.
**Solution:** PM identifies capacity gap by end of Week 1. You approve freelance hire. Get it done.

### Pitfall 5: "We'll Iterate Later"
**Reality:** "Later" becomes never. Deadlines enforce discipline.
**Solution:** Hard Phase 1–3 deadlines. Phase 4 is for iteration. Stick to it.

### Pitfall 6: "I'm Not Sure If This Is Working"
**Reality:** You're flying blind without metrics.
**Solution:** Set up analytics Week 1 (Google Analytics, Hotjar). Review metrics every Friday. Adjust if underperforming.

---

## THE AGENT AS YOUR FORCE MULTIPLIER

If you're using an AI agent or AI-assisted orchestration:

**The agent should:**
- ✅ Break down each initiative into micro-tasks
- ✅ Identify dependencies and critical paths
- ✅ Generate weekly reports automatically
- ✅ Flag risks 1 week in advance
- ✅ Suggest optimizations ("Design is over-capacity; suggest freelance hire")
- ✅ Maintain shared dashboards
- ✅ Ensure nothing falls through cracks

**The agent should NOT:**
- ❌ Write final copy (you review all customer-facing content)
- ❌ Make strategic decisions (you make calls on "pivot to Real Estate vs. Manufacturing")
- ❌ Approve spend (you approve all budget)
- ❌ Set deadlines unilaterally (you own timeline)

**How to brief the agent:**
```
You are orchestrating a 10-week website implementation. Your job is to keep this 
on track, flag blockers, and ensure we hit every deadline.

Here's the Master Prompt [paste entire prompt].

Your first action: 
1. Summarize the 10-week roadmap (4 phases, 17 initiatives)
2. Identify the 3 critical blockers that could derail Weeks 1–3
3. Create a shared dashboard (Notion template) to track all initiatives
4. Schedule the Week 1 kickoff meeting (attendees: Reagan, PM, Product, Dev, Design, Content)

You'll report every Friday with: status, metrics, blockers, next week priorities.

Start now. What's the first blocker you identify, and what do you recommend?
```

---

## TIMELINE SUMMARY

```
Week 1      Week 2      Week 3      Week 4      Week 5      Week 6
Phase 1 Start Phase 1 Live Phase 1 Done Phase 2 Start Phase 2 Cont Phase 2 Done

Week 7      Week 8      Week 9      Week 10
Phase 3 Start Phase 3 Cont Phase 3 Cont Phase 3 Done + Handoff

Phase 4 begins Week 11 (ongoing — no deadline, but weekly cadence)
```

---

## FINAL NOTES FOR REAGAN (YOU)

### Your Responsibilities
1. **Unlock blockers:** When something stalls (pricing decision, founder bio approval), you own getting it unstuck
2. **Make judgment calls:** If "delay or reduce scope," you decide
3. **Celebrate wins:** Every initiative that ships is a team victory. Acknowledge publicly
4. **Stay informed:** Read PM's Friday reports. Review metrics. Ask questions

### Your Time Commitment
- **Week 1:** 2 hours (kickoff + pricing decision + founder bio + team photos)
- **Weeks 2–3:** 1 hour/week (PM sync + final approvals)
- **Weeks 4–6:** 0.5 hours/week (monitoring)
- **Weeks 7–10:** 0.5 hours/week (monitoring + Phase 4 planning)

**Total: ~10 hours across 10 weeks.** Doable alongside your other CEO responsibilities.

### Success Looks Like
By Week 10:
- All 17 initiatives live
- Conversion score improved 6.5 → 9/10
- Enterprise deal closure rate up 35%
- Sales team using new messaging in every conversation
- You have a playbook for ongoing optimization

---

## HOW TO DISTRIBUTE THE PROMPTS

### To Your Project Manager
- **Master Prompt:** Their project charter. Print it, reference daily
- **Phase 1 Sub-Prompt:** Detailed execution guide for Weeks 1–3
- **Phase 2 Sub-Prompt:** (You'll create this; PM references it in Week 4)
- **Phase 3 Sub-Prompt:** (You'll create this; PM references it in Week 7)

### To Your Team
- **Each team member gets:** Their specific initiatives + the weekly checklist for their phase
  - Content: Phase 1 sections covering Initiative 1.1, 1.4, etc.
  - Design: Master Prompt + Phase 1 design requirements
  - Dev: Master Prompt + Phase 1 build specifications

### To Your AI Agent (If Using)
- **Everything:** Full Master Prompt + all Phase Sub-Prompts (so the agent can see the full roadmap)
- **Plus:** This Implementation Guide (so it understands how to work with your team)

---

## NEXT STEPS

1. **Today:** Share this guide + Master Prompt with your PM (or identify who will be your PM)
2. **Tomorrow:** Schedule Week 1 kickoff meeting
3. **Monday:** Kickoff happens. Execution begins.
4. **Friday:** First weekly status report arrives in your inbox

You're ready. Let's go. 🚀

---

**END OF IMPLEMENTATION GUIDE**
